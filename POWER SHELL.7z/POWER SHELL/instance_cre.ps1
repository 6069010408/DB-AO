$instance=./box.ps1
#echo $instance
(Get-Content ConfFile.ini) -Replace 'TEST9', $instance | Set-Content ConfFile.ini
cd Z:
./Setup.exe /ConfigurationFile=C:\Users\VSRMILLIONBRODJ\Documents\ConfFile.ini