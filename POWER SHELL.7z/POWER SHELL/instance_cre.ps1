Set-Location  -Path C:\Users\VSRMILLIONBRODJ\Documents
#New-PSDrive -Name "Z" -PSProvider "FileSystem" -Root "\\w10961dblab99\d$\SQLSource\sql2019DevEdtn\sql2019DevEdtn.iso" -Persist
#Remove-PSDrive -Name Z -Force

$Hostname=$env:computername | Select-Object
$version=./box_version.ps1
echo $version
echo "\\$Hostname\d$\SQLSource\$version\sql2019DevEdtn.iso"

Mount-DiskImage -ImagePath "\\$Hostname\d$\SQLSource\$version\$version.iso"
$label=(Get-DiskImage -ImagePath "\\w10961dblab99\d$\SQLSource\$version\$version.iso" |Get-volume |Select-Object -ExpandProperty DriveLetter|Ft -HideTableHeaders|Out-String)[0]

#Get-PSDrive -PSProvider FileSystem 

$instance=./box_instance.ps1
#echo $instance
$oldinst=(((Get-Content ConfFile.ini)|select-String -pattern 'INSTANCENAME') -split '"')[1]
(Get-Content ConfFile.ini) -Replace $oldinst, $instance | Set-Content ConfFile.ini

#$SERVER_RAM=(systeminfo | Select-String 'Total Physical Memory:').ToString().Split(':')[1].Trim()
Write-Host "                   "
Write-Host "le server a une RAM de " $SERVER_RAM
Write-Host " 
                    "  
cd ($label + ":") 
./Setup.exe /ConfigurationFile=C:\Users\VSRMILLIONBRODJ\Documents\ConfFile.ini 
C:
Dismount-DiskImage -ImagePath "\\w10961dblab99\d$\SQLSource\sql2019DevEdtn\sql2019DevEdtn.iso"