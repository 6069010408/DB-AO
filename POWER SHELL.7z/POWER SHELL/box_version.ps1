Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'SQL Version Entry form'
$form.Size = New-Object System.Drawing.Size(500,600)
$form.StartPosition = 'CenterScreen'

$okButton = New-Object System.Windows.Forms.Button
$okButton.Location = New-Object System.Drawing.Point(170,320)
$okButton.Size = New-Object System.Drawing.Size(75,23)
$okButton.Text = 'OK'
$okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $okButton
$form.Controls.Add($okButton)

$cancelButton = New-Object System.Windows.Forms.Button
$cancelButton.Location = New-Object System.Drawing.Point(270,320)
$cancelButton.Size = New-Object System.Drawing.Size(75,23)
$cancelButton.Text = 'Cancel'
$cancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $cancelButton
$form.Controls.Add($cancelButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10,20)
$label.Size = New-Object System.Drawing.Size(280,20)
$label.Text = 'Please select a SQL Version'
$form.Controls.Add($label)

$listBox = New-Object System.Windows.Forms.ListBox
$listBox.Location = New-Object System.Drawing.Point(100,100)
$listBox.Size = New-Object System.Drawing.Size(260,400)
$listBox.Height = 150
[void] $listBox.Items.Add('sql2022DevEdtn')
[void] $listBox.Items.Add('sql2022StdEdtn')
[void] $listBox.Items.Add('sql2022EntEdtn')
[void] $listBox.Items.Add('              ')
[void] $listBox.Items.Add('sql2019DevEdtn')   
[void] $listBox.Items.Add('sql2019StdEdtn')
[void] $listBox.Items.Add('sql2019EntEdtn')
[void] $listBox.Items.Add('              ')
[void] $listBox.Items.Add('sql2017DevEdtn')
[void] $listBox.Items.Add('sql2017StdEdtn')
[void] $listBox.Items.Add('sql2017EntEdtn')
[void] $listBox.Items.Add('              ')
[void] $listBox.Items.Add('sql2016DevEdtn')
[void] $listBox.Items.Add('sql2016StdEdtn')
[void] $listBox.Items.Add('sql2016EntEdtn')
[void] $listBox.Items.Add('              ')
[void] $listBox.Items.Add('              ')
[void] $listBox.Items.Add('sql2014DevEdtn')
[void] $listBox.Items.Add('sql2014StdEdtn')
[void] $listBox.Items.Add('sql2014EntEdtn')
[void] $listBox.Items.Add('              ')
 


$form.Controls.Add($listBox)

$form.Topmost = $true

$result = $form.ShowDialog()

if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
    $x = $listBox.SelectedItem
    $x
}