$Computers=Get-Content -Path C:\Users\VSRMILLIONBRODJ\Documents\KO_SPLUNK.txt
Foreach ($computer in $Computers)
	{
	Find-DbaInstance -computer $computer |Get-DbaStartupParameter|Select-Object ErrorLog, ComputerName 
	}