$liste=$liste=Get-Content -path C:\Users\VSRMILLIONBRODJ\Documents\REPO_SQL_OCSIN\GE-ADMIN-SERVERS.txt
foreach ($serv in $liste)
{Try {Test-Connection -ComputerName $serv -count 1} catch{$_|Out-File Error_connect_GE-admin.txt}}